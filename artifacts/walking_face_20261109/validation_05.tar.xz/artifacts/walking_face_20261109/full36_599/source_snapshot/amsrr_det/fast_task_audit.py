"""Equivalent evaluator reduction in native code; no control inputs added."""
import ctypes,hashlib,os,subprocess,math
from pathlib import Path
import numpy as np
import mujoco
from amsrr_det.task_audit import TaskAudit
from .model import ROOT

class FastTaskAudit(TaskAudit):
    def __init__(self,*args,clearance_period=0.,face_axis=None,**kwargs):
        self.clearance_period=float(clearance_period);self.next_clearance=0.
        self.face_axis=face_axis;self.face_active=False;self.face_stats=np.zeros(15)
        super().__init__(*args,**kwargs)
        root=Path(mujoco.__file__).parent;source=Path(__file__).with_suffix('.cc')
        version=mujoco.mj_versionString();digest=hashlib.sha256(source.read_bytes()+version.encode()).hexdigest()[:16]
        binary=ROOT/'build'/('fast_task_audit_'+digest+'.so')
        binary.parent.mkdir(exist_ok=True)
        if not binary.exists():
            temporary=binary.with_suffix('.'+str(os.getpid())+'.so')
            subprocess.run(['c++','-O3','-std=c++17','-shared','-fPIC','-Wall','-Wextra','-I'+str(root/'include'),str(source),str(root/('libmujoco.so.'+version)),'-Wl,-rpath,'+str(root),'-o',str(temporary)],check=True)
            os.replace(temporary,binary)
        self.library=ctypes.CDLL(str(binary))
        if self.library.audit_version()!=mujoco.mj_version():raise RuntimeError('MuJoCo header/library version mismatch')
        ptr=ctypes.c_void_p;integer=ctypes.c_int
        self.call=self.library.audit_step;self.call.restype=integer
        self.call.argtypes=[ptr,ptr,integer,integer,integer,integer,ptr,ptr,ptr,integer,ptr,ptr,ptr,ptr,ptr,integer,ptr,integer,ptr,ctypes.c_double,ptr,ptr,ptr,ptr,ptr,ptr]
        self._native_meta=[np.array(x,dtype=np.int32)for x in [list(self.link_bodies.values()),self.groups,self.allowed_support,self.ai,self.qadr,self.vadr]]
        self.size=np.ascontiguousarray(self.size,dtype=float)
        if min(self.object_geom,self.object_body,*self.link_bodies.values(),*self.ai,*self.qadr,*self.vadr)<0:raise ValueError('missing audit body, joint or actuator')
        self._stats=np.zeros(14);self._stats[7]=np.inf;self._stats[13]=np.nan
        self._anchors=np.zeros((len(self.links),10))
        self._vertices=np.ascontiguousarray(self.shape.vertices if self.shape is not None and self.shape.vertices is not None else np.empty((0,3)),dtype=float)
        self._shape=0 if self.shape is None or self.shape.family in ['box','elongated_box'] else {'ellipsoid':1,'cylinder':2}.get(self.shape.family,3)
        # These arrays are owned by this evaluator and never replaced. Cache
        # their addresses instead of rebuilding ctypes wrappers every step.
        b,g,s,ai,qi,vi=self._native_meta
        address=lambda x:x.ctypes.data
        self._arguments=(self.object_geom,len(self.links),address(b),address(g),address(s),len(ai),
            address(ai),address(qi),address(vi),address(self.limits),address(self.effort),self._shape,
            address(self.size),len(self._vertices),address(self._vertices),self.support_top,
            address(self._stats),address(self.saturated_time),address(self.gap_time),
            address(self._anchors),address(self.last_normal_loads))
        self._unexpected=np.empty((16,2),dtype=np.int32)
        self.batch=self.library.audit_advance;self.batch.restype=ctypes.c_int
        self.batch.argtypes=self.call.argtypes[:2]+[ctypes.c_int]+self.call.argtypes[2:-1]+[ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p]
        self.batch_pairs=np.empty((4096,2),np.int32);self.batch_count=np.zeros(1,np.int32)
        if self.proximity.joint_motion is not None:
            self.proximity.joint_motion=_NativeMotionBound(self.proximity.joint_motion,self.library)

    def update(self,data,*,carried=False,grasp_contact_allowed=True):
        m=self.plant.mj
        if data.model._address!=m._address:raise ValueError('data/model mismatch')
        if data.ncon>len(self._unexpected):self._unexpected=np.empty((data.ncon,2),dtype=np.int32)
        count=self.call(m._address,data._address,carried,grasp_contact_allowed,*self._arguments,self._unexpected.ctypes.data)
        if count<0:raise ValueError('audit requires 3D point contacts')
        self.other_contacts.update(tuple(sorted([self.names[a],self.names[b]]))for a,b in self._unexpected[:count])
        (self.max_force,self.max_moment,self.max_penetration,self.max_joint_speed,self.max_effort_ratio,self.max_joint_limit_violation,self.max_clearance,self.min_clearance_carried,self.max_raw_effort_ratio,self.max_servo_error,self.max_slip,self.max_material_displacement,self.longest_gap,last)=self._stats
        self.last_contact_time=None if np.isnan(last) else float(last);self.time=float(data.time)
        if data.time+1e-10>=self.next_clearance:
            violations,part,environment=self.proximity.check(data.qpos,grasp_contact_allowed)
            self.minimum_part_gap=min(self.minimum_part_gap,part);self.minimum_environment_gap=min(self.minimum_environment_gap,environment);self.clearance_violations.update(violations)
            self.next_clearance=float(data.time)+self.clearance_period

    def advance(self,data,steps,*,carried=False,grasp_contact_allowed=True):
     while steps>0:
      until=max(1,math.ceil((self.next_clearance-data.time-1e-10)/self.plant.mj.opt.timestep));n=min(steps,until)
      reason=self.batch(self.plant.mj._address,data._address,n,carried,grasp_contact_allowed,*self._arguments,4096,self.batch_pairs.ctypes.data,self.batch_count.ctypes.data,
          self.face_axis if self.face_active and self.face_axis is not None else -1,self.face_stats.ctypes.data)
      self.other_contacts.update(tuple(sorted([self.names[a],self.names[b]]))for a,b in self.batch_pairs[:self.batch_count[0]])
      (self.max_force,self.max_moment,self.max_penetration,self.max_joint_speed,self.max_effort_ratio,self.max_joint_limit_violation,self.max_clearance,self.min_clearance_carried,self.max_raw_effort_ratio,self.max_servo_error,self.max_slip,self.max_material_displacement,self.longest_gap,last)=self._stats
      self.last_contact_time=None if np.isnan(last)else float(last);self.time=float(data.time)
      if data.time+1e-10>=self.next_clearance:
       violations,part,environment=self.proximity.check(data.qpos,grasp_contact_allowed);self.minimum_part_gap=min(self.minimum_part_gap,part);self.minimum_environment_gap=min(self.minimum_environment_gap,environment);self.clearance_violations.update(violations);self.next_clearance=float(data.time)+self.clearance_period
      if reason>4:raise ValueError('batch audit contract '+str(reason))
      if reason:return {1:'nonfinite_physical_state',2:'motor_effort_limit',3:'extreme_control_instability',4:'extreme_collision'}[reason]
      steps-=n
     return None

    def result(self):
        result=super().result()
        result['clearance_sampling_period_s']=self.clearance_period
        if self.face_axis is not None:
            s=self.face_stats
            result['contact_faces']=dict(axis=self.face_axis,integration_steps=int(s[0]),violating_steps=int(s[1]),
                maximum_non_side_normal_force_n=float(s[2]),non_side_normal_impulse_ns=float(s[3]),
                maximum_non_side_axis_torque_nm=float(s[4]),first_violation_s=float(s[5]) if s[1] else None,
                last_violation_s=float(s[6]) if s[1] else None,
                worst_geom=self.plant.mj.geom(int(s[7])).name if s[14] else None,
                worst_point_local=s[8:11].tolist(),worst_normal_local=s[11:14].tolist(),
                normal_force_zero_tolerance_n=1e-6,passes=bool(s[0]>0 and s[1]==0))
        return result



class _NativeMotionBound:
    def __init__(self,bound,library):
        self.original=bound
        self.library=library
        self.call=self.library.motion_maximum;p=ctypes.c_void_p;i=ctypes.c_int
        self.call.argtypes=[i,i,i,i,p,p,p,p,p,p,p];self.call.restype=None
        self.qi=np.asarray(bound.qi,dtype=np.int32);self.levers=bound.levers
        self.roots=np.full(len(self.levers),-1,np.int32);self.reaches=np.zeros(len(self.roots))
        for k,(rows,reach)in bound.roots.items():self.roots[rows]=k;self.reaches[rows]=reach
        self._arguments=(len(self.roots),len(self.qi),self.qi.ctypes.data,self.levers.ctypes.data,self.roots.ctypes.data,self.reaches.ctypes.data)
    def maximum(self,states,anchor):
        states=np.atleast_2d(states)
        if len(states)!=1:return self.original.maximum(states,anchor)
        states=np.ascontiguousarray(states,dtype=float);anchor=np.ascontiguousarray(anchor,dtype=float);output=np.zeros(1)
        if states.shape[1]!=len(anchor):raise ValueError("state/anchor shape mismatch")
        address=lambda x:x.ctypes.data
        self.call(1,states.shape[1],*self._arguments,address(states),address(anchor),address(output))
        return output
