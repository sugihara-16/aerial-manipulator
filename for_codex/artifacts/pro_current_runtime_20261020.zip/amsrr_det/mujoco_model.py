"""MuJoCo dynamics with source inertias, movable joints and actual rotor sites."""
from __future__ import annotations
from dataclasses import dataclass, replace
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
import pinocchio as pin
import mujoco
from .model import ROOT, build_model, transform

# Source PhysX Dock decomposition; other parts retain the CAD component hulls.
# This is a reusable part cache, not a catalogue of assembled structures.
CONTACT_CACHE=ROOT/'build/collision_physx_docks'


def contact_dynamics_model(plant,selected_links):
    """Omit prohibited collision pairs; callers MUST audit full geometry.

    This is equivalent only until the full clearance boundary is crossed.
    Body inertias, joints, actuators and all permitted task contacts stay.
    """
    doc=ET.fromstring(plant.xml)
    for body in doc.find('worldbody').iter():
        for geom in list(body.findall('geom')):
            name=geom.get('name','')
            if name not in ['object','support','destination_support','floor'] and not any(name.startswith(link+'/') for link in selected_links):
                body.remove(geom)
    xml=ET.tostring(doc,encoding='unicode');model=mujoco.MjModel.from_xml_string(xml)
    model.opt.timestep=plant.mj.opt.timestep
    if (model.nq,model.nv,model.nbody,model.nu)!=(plant.mj.nq,plant.mj.nv,plant.mj.nbody,plant.mj.nu):
        raise ValueError('collision pruning changed dynamic dimensions')
    for name in ['body_mass','body_inertia','body_ipos','body_iquat','jnt_type','jnt_qposadr','jnt_dofadr']:
        if not np.array_equal(getattr(model,name),getattr(plant.mj,name)):
            raise ValueError('collision pruning changed '+name)
    joints=[(j,model.joint(plant.pin.names[j]).id) for j in range(1,plant.pin.njoints)]
    return replace(plant,mj=model,xml=xml,joints=joints)


def numbers(x):
    return ' '.join(format(float(v), '.17g') for v in np.asarray(x).ravel())


def pose(T):
    xyzw = pin.Quaternion(T.rotation).coeffs()
    return dict(pos=numbers(T.translation), quat=numbers(xyzw[[3, 0, 1, 2]]))


@dataclass
class PlantModel:
    pin: object
    meta: dict
    mj: object
    xml: str
    joints: list

    def configuration(self, q):
        """Convert coordinates independently of compiler joint order."""
        result = self.mj.qpos0.copy()
        for jid, mjid in self.joints:
            joint = self.pin.joints[jid]
            dest = self.mj.jnt_qposadr[mjid]
            if joint.nq == 7:
                result[dest:dest+3] = q[joint.idx_q:joint.idx_q+3]
                result[dest+3:dest+7] = q[joint.idx_q+np.array([6, 3, 4, 5])]
            else:
                result[dest] = q[joint.idx_q]
        return result

    def observation(self, data):
        q = pin.neutral(self.pin)
        v = np.zeros(self.pin.nv)
        for jid, mjid in self.joints:
            joint = self.pin.joints[jid]
            src, vel = self.mj.jnt_qposadr[mjid], self.mj.jnt_dofadr[mjid]
            if joint.nq == 7:
                q[joint.idx_q:joint.idx_q+3] = data.qpos[src:src+3]
                q[joint.idx_q+3:joint.idx_q+7] = data.qpos[src+np.array([4, 5, 6, 3])]
                R = pin.Quaternion(q[joint.idx_q+3:joint.idx_q+7]).matrix()
                v[joint.idx_v:joint.idx_v+3] = R.T @ data.qvel[vel:vel+3]
                v[joint.idx_v+3:joint.idx_v+6] = data.qvel[vel+3:vel+6]
            else:
                q[joint.idx_q] = data.qpos[src]
                v[joint.idx_v] = data.qvel[vel]
        return q, v


def make_plant(n=1, edges=(), payload=None, *, timestep=.001,
               meshes=True, mesh_cache=None, floor=False):
    model, meta = build_model(n, edges, payload)
    meta['material_mesh_cache']=str(Path(mesh_cache or ROOT/'build/collision_meshes').resolve()) if meshes else None
    doc = ET.Element('mujoco', model='amsrr_det')
    ET.SubElement(doc, 'compiler', angle='radian', inertiafromgeom='false',
                  autolimits='true', fusestatic='false')
    option = ET.SubElement(doc, 'option', timestep=str(timestep),
                          gravity=numbers(model.gravity.linear), integrator='implicitfast',
                          cone='elliptic', iterations='60', tolerance='1e-10')
    ET.SubElement(option, 'flag', filterparent='disable', autoreset='disable')
    default = ET.SubElement(doc, 'default')
    ET.SubElement(default, 'geom', friction='.6 0 0', condim='3',
                  solref='.01 1', solimp='.95 .95 .001')
    assets = ET.SubElement(doc, 'asset')
    world = ET.SubElement(doc, 'worldbody')
    ET.SubElement(world, 'light', pos='0 0 4', dir='0 0 -1')
    bodies = {0: world}
    actuators = ET.SubElement(doc, 'actuator')
    contact = ET.SubElement(doc, 'contact')
    data = model.createData()
    neutral = pin.neutral(model)
    byjoint = {a['joint']: a for a in meta['actuators']}
    for jid in range(1, model.njoints):
        j = model.joints[jid]
        b = ET.SubElement(bodies[model.parents[jid]], 'body', name=f'joint{jid}',
                          **pose(model.jointPlacements[jid]))
        bodies[jid] = b
        inertia = model.inertias[jid]
        I = inertia.inertia
        ET.SubElement(b, 'inertial', mass=str(inertia.mass), pos=numbers(inertia.lever),
                      fullinertia=numbers([I[0,0],I[1,1],I[2,2],I[0,1],I[0,2],I[1,2]]))
        if j.nq == 7:
            ET.SubElement(b, 'freejoint', name=model.names[jid])
        else:
            a = byjoint[jid]
            axis = pin.computeJointJacobian(model, data, neutral, jid)[3:, j.idx_v]
            ET.SubElement(b, 'joint', name=a['name'], type='hinge', axis=numbers(axis),
                          range=numbers([a['lower'], a['upper']]),
                          armature=str(model.armature[j.idx_v]))
    frame_bodies = {}
    for name, fid in meta['frames'].items():
        frame = model.frames[fid]
        b = ET.SubElement(bodies[frame.parentJoint], 'body', name=name,
                          **pose(frame.placement))
        ET.SubElement(b, 'site', name=name, size='.002', rgba='0 0 0 0')
        frame_bodies[name] = b
    for a in meta['actuators']:
        ET.SubElement(actuators, 'general', name=a['name'], joint=a['name'],
                      gaintype='fixed', gainprm=str(a['kp']), biastype='affine',
                      biasprm=numbers([0, -a['kp'], -a['kd']]),
                      forcerange=numbers([-a['effort'], a['effort']]))
    for i, r in enumerate(meta['rotors']):
        ET.SubElement(actuators, 'general', name=f'rotor{i}',
                      site=model.frames[r['frame']].name, gear='0 0 1 0 0 0',
                      ctrlrange=numbers([r['minimum'],r['maximum']]))
    if meshes:
        add_meshes(assets, frame_bodies, contact, meta, mesh_cache)
    if payload is not None:
        family=payload.get('shape','box');kind='box' if family=='elongated_box' else family
        if family in ['triangular_prism','tapered_box']:
            ET.SubElement(assets,'mesh',name='payload_shape',vertex=numbers(payload['vertices']),
                          face=' '.join(str(int(i)) for i in np.asarray(payload['faces']).ravel()))
            geometry=dict(type='mesh',mesh='payload_shape')
        elif family=='cylinder':
            geometry=dict(type=kind,size=numbers(np.asarray(payload['size'])[[0,2]]/2))
        else:
            geometry=dict(type=kind,size=numbers(np.asarray(payload['size'])/2))
        ET.SubElement(frame_bodies['object'],'geom',name='object',rgba='.8 .4 .15 1',**geometry)
    if floor:
        ET.SubElement(world, 'geom', name='floor', type='plane', size='10 10 .1',
                      friction='.8 0 0', rgba='.8 .8 .8 1')
    xml = ET.tostring(doc, encoding='unicode')
    mj = mujoco.MjModel.from_xml_string(xml)
    joints = [(i, mujoco.mj_name2id(mj, mujoco.mjtObj.mjOBJ_JOINT, model.names[i]))
              for i in range(1, model.njoints)]
    return PlantModel(model, meta, mj, xml, joints)


def add_meshes(assets, frame_bodies, contact, meta, mesh_cache):
    cache = Path(mesh_cache or ROOT/'build/collision_meshes')
    source = ROOT/'assets/robots/holon/holon.urdf'
    tree = ET.parse(source)
    unique, links = {}, []
    for link in tree.findall('link'):
        for collider in link.findall('collision'):
            mesh = collider.find('geometry/mesh')
            path = source.parent / mesh.get('filename')
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            scale = np.fromstring(mesh.get('scale', '1 1 1'), sep=' ')
            if digest not in unique:
                manifest = json.loads((cache/digest/'manifest.json').read_text())
                if manifest['source_sha256'] != digest:
                    raise ValueError('stale collision geometry')
                names = []
                for k, part in enumerate(manifest['parts']):
                    file = (cache/digest/part['file']).resolve()
                    if hashlib.sha256(file.read_bytes()).hexdigest() != part['sha256']:
                        raise ValueError('collision geometry hash mismatch')
                    name = f'mesh{len(unique)}_{k}'
                    ET.SubElement(assets, 'mesh', name=name, file=str(file), scale=numbers(scale))
                    names.append(name)
                unique[digest] = names
            links.append(link.get('name'))
            for module in range(meta['modules']):
                name = f'm{module}/'+link.get('name')
                for k, asset in enumerate(unique[digest]):
                    ET.SubElement(frame_bodies[name], 'geom', name=f'{name}/{k}',
                                  type='mesh', mesh=asset, **pose(transform(collider.find('origin'))),
                                  rgba='0.25 0.5 0.75 1')
    manifest = json.loads((ROOT/'configs/robot/holon_nominal_collision_pairs_v1.json').read_text())
    if hashlib.sha256(source.read_bytes()).hexdigest() != manifest['urdf_sha256']:
        raise ValueError('stale exclusion manifest')
    adjacent = {frozenset([j.find('parent').get('link'), j.find('child').get('link')])
                for j in tree.findall('joint')}
    for module in range(meta['modules']):
        for i, a in enumerate(links):
            for j, b in enumerate(links[i+1:], i+1):
                if frozenset([a,b]) in adjacent or [i,j] in manifest['authored_overlap_geometry_pairs']:
                    ET.SubElement(contact, 'exclude', body1=f'm{module}/{a}', body2=f'm{module}/{b}')
    for e in meta['edges']:
        mechanism = lambda p: ('pitch_dock_mech' if p.startswith('pitch') else 'yaw_dock_mech')+p[-1]
        ET.SubElement(contact, 'exclude', body1=f"m{e['a']}/{mechanism(e['port_a'])}",
                      body2=f"m{e['b']}/{mechanism(e['port_b'])}")


def coat_grippers(xml, prefixes, *, stiffness=7500., damping=75., friction=4.5,
                  impedance=.01):
    """Map the declared per-contact coating K/C to MuJoCo soft constraints.

    With constant impedance d, R=(1-d)/d * diagA, k=K*R, b=C*R.
    Thus at rest F=K*penetration; dynamically F=K*penetration-C*velocity-a/R.
    This last acceleration term is MuJoCo regularization, not physical coating.
    Low d reduces it. Verification must include timestep/model sensitivity.
    Coefficients use compiled geometry/body masses, never contact-force truth.
    This conversion is for the selected gripper against the task object.
    """
    doc=ET.fromstring(xml);m=mujoco.MjModel.from_xml_string(xml)
    obj=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_GEOM,'object')
    for geom in doc.findall('.//geom'):
        name=geom.get('name','')
        if not any(name.startswith(prefix+'/') for prefix in prefixes):continue
        gid=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_GEOM,name)
        diag=sum(m.body_invweight0[m.geom_bodyid[g],0] for g in [gid,obj])
        geom.set('solref',numbers([-stiffness*(1-impedance)*diag,
                                  -damping*(1-impedance)*diag]))
        geom.set('solimp',numbers([impedance,impedance,.001]))
        geom.set('friction',numbers([friction,0,0]));geom.set('priority','1')
    return ET.tostring(doc,encoding='unicode')
